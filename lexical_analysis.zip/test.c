#include <stdio.h>

void test(){
    int a, b,c;
    a=2;
    b=5;
    c=a+b;
}