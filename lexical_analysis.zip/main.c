#include <stdio.h>
#include <string.h>

int main() {
    int i, j = 0, x = 0, t = 0, ss = 0;
    int ss_print[15] = {0}, key_print[10] = {0}, idn_pri[10] = {0};
    int ss_flag = 0, kw_flag = 0, wrdfnd = 0;
    char ch;
    char kw[50];  // Increased size to avoid overflow
    char mac1[15][50] = {{0}};
    char spl_symb[] = {'#','+','-','*','/','>','<','(',')','=',',',';','{','}'};
    char keywrds[10][20] = {"include","void","main","stdio.h","conio.h","getch","int","char","float"};
    
    FILE *in = fopen("test.c","r");
    if (in == NULL) {
        printf("File not found!\n");
        return 0;
    }

    while ((ch = fgetc(in)) != EOF) {
        ss_flag = 0;
        wrdfnd = 0;

        // Check special symbols
        for (i = 0; i < 14; i++) {
            if (ch == spl_symb[i]) {
                ss++;
                ss_print[i]++;
                ss_flag = 1;
            }
        }

        // Build words (keywords or identifiers)
        if (ss_flag == 0 && ch != ' ' && ch != '\n' && ch != '\t') {
            if ((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z') || ch == '.') {
                kw[kw_flag ? j : 0] = ch;
                kw_flag = 1;
                j++;
            }
        } else if (kw_flag == 1) {
            kw[j] = '\0';
            wrdfnd = 1;
        }

        // Check if the word is a keyword or identifier
        if (wrdfnd == 1) {
            int kw_print_flag = 0;
            for (i = 0; i < 10; i++) {
                if (strcmp(kw, keywrds[i]) == 0) {
                    key_print[i]++;
                    kw_print_flag = 1;
                    break;
                }
            }

            if (!kw_print_flag) {
                // It's an identifier
                t = 0;
                for (i = 0; i < x; i++) {
                    if (strcmp(kw, mac1[i]) == 0) {
                        idn_pri[i]++;
                        t = 1;
                        break;
                    }
                }
                if (t == 0) {
                    strcpy(mac1[x], kw);
                    idn_pri[x] = 1;
                    x++;
                }
            }
            j = 0;
            kw_flag = 0;
        }
    }

    fclose(in);

    // Print tables
    printf("\nSymbol Table\n");
    for (i = 0; i < 14; i++)
        printf("%d \t %c \t %d\n", i, spl_symb[i], ss_print[i]);
    printf("Total special symbols: %d\n\n", ss);

    printf("Keyword Table\n");
    for (i = 0; i < 10; i++)
        if (key_print[i] != 0)
            printf("%d \t %d \t %s\n", i+1, key_print[i], keywrds[i]);

    printf("\nIdentifier Table\n");
    for (i = 0; i < x; i++)
        printf("%d \t %s \t %d\n", i+1, mac1[i], idn_pri[i]);

    return 0;
}
